from django import forms
from employees.models import employees

class ContactForm(forms.Form):
    CHOICES=[('dcare','dcare'),
         ('admin','admin'),
		 ('everyone','everyone')]
    togroup = forms.ChoiceField(choices=CHOICES, widget=forms.RadioSelect())
    yourname = forms.CharField(required=False, label='Your Name')
    message = forms.CharField(widget=forms.Textarea)