from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.shortcuts import render
from django.template.loader import get_template
from django.template import Context
from django.core.mail import send_mail
from mysite.forms import ContactForm
import datetime
from employees.models import employees
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect
from django.conf import settings

import twilio
import twilio.rest

def hello(request):
    return HttpResponse("Hello world")

def thanks(request):
    if not request.user.is_authenticated():
        return HttpResponseRedirect('//')
    else:
        html = "Message(s) Sent!\n" + '<a href="/">Return Home </a>'
        return HttpResponse(html)


def homepage(request):
    if not request.user.is_authenticated():
        return HttpResponseRedirect('//')
    else:
        return render(request, 'base.html')

def current_datetime(request):
    if not request.user.is_authenticated():
        return HttpResponseRedirect('//')
    else:
        now = datetime.datetime.now()
        return render(request, 'current_datetime.html', {'current_date': now})

def hours_ahead(request, offset):
    if not request.user.is_authenticated():
        return HttpResponseRedirect('//')
    else:


        try:
            offset = int(offset)
        except ValueError:
            raise Http404()
        dt = datetime.datetime.now() + datetime.timedelta(hours=offset)
        return render(request, 'hours_ahead.html', {'hour_offset':offset,'next_time': dt})
        #return HttpResponse(html)


#This is working! WOohoo!
def contact(request):
    if not request.user.is_authenticated():
        return HttpResponseRedirect('/')
    else:
        if request.method == 'POST':
            form = ContactForm(request.POST)
            if form.is_valid():
                cd = form.cleaned_data
                client = twilio.rest.TwilioRestClient('AC71641f236c273d84e7d1d570370b53ac', '7f648ae24da547ad0b7e159bcbe9596d')


                recipients = employees.objects.filter(group__contains=cd['togroup'])
                if cd['togroup'] != "everyone":
                    for recipient in recipients:
                        client.messages.create(body=cd['message'],to=recipient.phone_number, from_='+19733595858')

                    return HttpResponseRedirect('/contact/thanks/')
                else:
                    recipients = employees.objects.all()
                    for recipient in recipients:
                        client.messages.create(body=cd['message'], to=recipient.phone_number, from_='+19733595858')
                    return HttpResponseRedirect('/contact/thanks/')
        else:
            form = ContactForm()
        return render(request, 'contact_form.html', {'form':
    form})
